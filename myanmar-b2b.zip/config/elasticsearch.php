<?php 

return [
    'hosts' => [env('ELASTICSEARCH_HOST', 'localhost:9200')],
    'retries' => 1,
];