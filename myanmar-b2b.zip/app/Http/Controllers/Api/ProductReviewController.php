<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ProductReview;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Notifications\NewProductReview;

class ProductReviewController extends Controller
{

    /**
     * Get reviews for a specific product
     */
    public function productReviews($productId)
    {
        try {
            \Log::info('Fetching reviews for product:', ['product_id' => $productId]);

            // First, check if product exists
            $product = Product::find($productId);
            if (!$product) {
                return response()->json([
                    'success' => false,
                    'message' => 'Product not found'
                ], 404);
            }

            $reviews = ProductReview::where('product_id', $productId)
                ->with('user') // Eager load user relationship
                ->where('status', 'approved')
                ->orderBy('created_at', 'desc')
                ->get();

            \Log::info('Reviews found:', ['count' => $reviews->count()]);

            return response()->json([
                'success' => true,
                'data' => $reviews
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to fetch reviews:', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch reviews',
                'error' => env('APP_DEBUG') ? $e->getMessage() : null
            ], 500);
        }
    }

    /**
     * Get all reviews (admin only)
     */
    public function index(Request $request)
    {
        $query = ProductReview::with(['user', 'product']);

        // If user is seller, only show reviews for their own products
        if (auth()->user()->hasRole('seller') && !auth()->user()->hasRole('admin')) {
            $query->whereHas('product', function ($q) {
                $q->where('seller_id', auth()->id());
            });
        }

        try {
            // Apply filters (status, product_id, user_id)
            if ($request->has('status')) {
                $query->where('status', $request->status);
            }
            if ($request->has('product_id')) {
                $query->where('product_id', $productId);
            }
            if ($request->has('user_id')) {
                $query->where('user_id', $request->user_id);
            }

            $reviews = $query->orderBy('created_at', 'desc')
                ->take($request->get('limit', 50))
                ->get();

            return response()->json([
                'success' => true,
                'data' => $reviews
            ]);
        } catch (\Exception $e) {
            \Log::error('Failed to fetch reviews:', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch reviews',
                'error' => env('APP_DEBUG') ? $e->getMessage() : null
            ], 500);
        }
    }

    /**
     * Get authenticated user's reviews
     */
    public function myReviews()
    {
        try {
            $reviews = ProductReview::where('user_id', auth()->id())
                ->with('product')
                ->orderBy('created_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'data' => $reviews
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to fetch user reviews:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch your reviews'
            ], 500);
        }
    }

    /**
     * Submit a new review
     */
    public function store(Request $request, $product)
    {
        // Normalise $product param — could be model instance or raw id from route
        $productId = is_object($product) ? $product->id : (int) $product;

        $validator = Validator::make($request->all(), [
            'rating'  => 'required|integer|min:1|max:5',
            'comment' => 'required|string|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Check if user already reviewed this product
            $existingReview = ProductReview::where('user_id', auth()->id())
                ->where('product_id', $productId)
                ->first();

            if ($existingReview) {
                return response()->json([
                    'success' => false,
                    'message' => 'You have already reviewed this product'
                ], 400);
            }

            $review = ProductReview::create([
                'user_id' => auth()->id(),
                'product_id' => $productId,
                'rating' => $request->rating,
                'comment' => $request->comment,
                'status' => 'approved'
            ]);

            try {
                $product = $review->product()->with('seller')->first();
                if ($product?->seller) {
                    $product->seller->notify(new NewProductReview($review));
                }
            } catch (\Exception $e) {
                \Log::warning('ProductReview notification failed: ' . $e->getMessage());
            }

            // Update product rating statistics
            $this->updateProductRating($productId);

            $updatedProduct = Product::find($productId);

            return response()->json([
                'success' => true,
                'message' => 'Review submitted successfully.',
                'data' => $review->load('user'),
                'product_rating' => $updatedProduct->average_rating,
                'product_review_count' => $updatedProduct->review_count,
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to submit review:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to submit review'
            ], 500);
        }
    }

    /**
     * Approve a review (admin only)
     */
    public function approve($id)
    {
        try {
            $review = ProductReview::findOrFail($id);

            // Check if review is already approved
            if ($review->status === 'approved') {
                return response()->json([
                    'success' => false,
                    'message' => 'Review is already approved'
                ], 400);
            }

            $review->update(['status' => 'approved']);

            // Update product rating
            $this->updateProductRating($review->product_id);

            return response()->json([
                'success' => true,
                'message' => 'Review approved successfully',
                'data' => $review->load(['user', 'product'])
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to approve review:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to approve review'
            ], 500);
        }
    }

    /**
     * Reject a review (admin only)
     */
    public function reject($id)
    {
        try {
            $review = ProductReview::findOrFail($id);

            // Check if review is already rejected
            if ($review->status === 'rejected') {
                return response()->json([
                    'success' => false,
                    'message' => 'Review is already rejected'
                ], 400);
            }

            $review->update(['status' => 'rejected']);

            // Update product rating (in case this was previously approved)
            $this->updateProductRating($review->product_id);

            return response()->json([
                'success' => true,
                'message' => 'Review rejected successfully',
                'data' => $review->load(['user', 'product'])
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to reject review:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to reject review'
            ], 500);
        }
    }

    /**
     * Update review status (admin only) - generic method for any status
     */
    public function updateStatus(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:approved,pending,rejected'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $review = ProductReview::findOrFail($id);
            $oldStatus = $review->status;
            $review->update(['status' => $request->status]);

            // Update product rating if status changed to/from approved
            if ($oldStatus === 'approved' || $request->status === 'approved') {
                $this->updateProductRating($review->product_id);
            }

            return response()->json([
                'success' => true,
                'message' => 'Review status updated successfully',
                'data' => $review->load(['user', 'product'])
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to update review status:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to update review status'
            ], 500);
        }
    }

    /**
     * Update a review (only the owner)
     */
    public function update(Request $request, $id)
    {
        $review = ProductReview::where('user_id', auth()->id())->findOrFail($id);

        $validator = Validator::make($request->all(), [
            'rating' => 'sometimes|integer|min:1|max:5',
            'comment' => 'sometimes|string|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            if ($request->has('rating')) {
                $review->rating = $request->rating;
            }
            if ($request->has('comment')) {
                $review->comment = $request->comment;
            }
            $review->save();

            // Recalculate product rating
            $this->updateProductRating($review->product_id);

            $updatedProduct = Product::find($review->product_id);

            return response()->json([
                'success' => true,
                'message' => 'Review updated successfully',
                'data' => $review->load('user'),
                'product_rating' => $updatedProduct->average_rating,
                'product_review_count' => $updatedProduct->review_count,
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to update review:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to update review'
            ], 500);
        }
    }

    /**
     * Delete a review (owner only)
     */
    public function destroy($id)
    {
        try {
            $review = ProductReview::where('user_id', auth()->id())->findOrFail($id);
            $productId = $review->product_id;
            $review->delete();

            // Recalculate product rating
            $this->updateProductRating($productId);

            $updatedProduct = Product::find($productId);

            return response()->json([
                'success' => true,
                'message' => 'Review deleted successfully',
                'product_rating' => $updatedProduct->average_rating,
                'product_review_count' => $updatedProduct->review_count,
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to delete review:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to delete review'
            ], 500);
        }
    }

    /**
     * Update product rating statistics
     */
    private function updateProductRating($productId)
    {
        try {
            $approvedReviews = ProductReview::where('product_id', $productId)
                ->where('status', 'approved')
                ->get();

            $product = Product::find($productId);

            if ($approvedReviews->count() > 0) {
                $averageRating = $approvedReviews->avg('rating');
                $reviewCount = $approvedReviews->count();

                $product->update([
                    'average_rating' => number_format((float) $averageRating, 2, '.', ''),
                    'review_count' => $reviewCount
                ]);
            } else {
                // If no approved reviews, reset the ratings
                $product->update([
                    'average_rating' => 0.00,
                    'review_count' => 0
                ]);
            }

        } catch (\Exception $e) {
            \Log::error('Failed to update product rating:', [
                'product_id' => $productId,
                'error' => $e->getMessage()
            ]);
        }
    }

    public function sellerReviews(Request $request)
    {
        try {
            $sellerId = Auth::id();
            $reviews = ProductReview::whereHas('product', function ($query) use ($sellerId) {
                $query->where('seller_id', $sellerId);
            })
                ->with(['user:id,name', 'product']) // Include only 'id' and 'name' from the User table
                ->orderBy('created_at', 'desc')
                ->paginate($request->per_page ?? 20);

            return response()->json([
                'success' => true,
                'data' => $reviews
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to fetch seller reviews:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch your product reviews'
            ], 500);
        }
    }

    public function seller(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|exists:products,id',
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'required|string|max:1000'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Check if user already reviewed this product
            $existingReview = ProductReview::where('user_id', auth()->id())
                ->where('product_id', $productId)
                ->first();

            if ($existingReview) {
                return response()->json([
                    'success' => false,
                    'message' => 'You have already reviewed this product'
                ], 400);
            }

            $review = ProductReview::create([
                'user_id' => auth()->id(),
                'product_id' => $productId,
                'rating' => $request->rating,
                'comment' => $request->comment,
                'status' => 'pending'
            ]);

            // Update product rating statistics
            $this->updateProductRating($productId);

            return response()->json([
                'success' => true,
                'message' => 'Review submitted successfully. It will be visible after approval.',
                'data' => $review->load('user')
            ]);

        } catch (\Exception $e) {
            \Log::error('Failed to submit review:', [
                'error' => $e->getMessage()
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to submit review'
            ], 500);
        }
    }
}