<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\UserAccountDeletionService;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Hash;
use App\Http\Resources\UserResource;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class UserController extends Controller
{
    use AuthorizesRequests;

    public function __construct(
        private readonly UserAccountDeletionService $accountDeletion,
    ) {
    }
    /**
     * Display a paginated list of users.
     */
    // In UserController::index() method
    public function index(Request $request)
    {
        $this->authorize('viewAny', User::class);

        $perPage = $request->input('per_page', 10);
        $search = $request->input('search');
        $role = $request->input('role');

        $status = $request->input('status'); // 'active' | 'inactive' | null

        $query = User::with('roles')
            ->when($search, function ($query) use ($search) {
                $query->where(function ($q) use ($search) {
                    $q->where('name', 'like', "%$search%")
                        ->orWhere('email', 'like', "%$search%")
                        ->orWhere('phone', 'like', "%$search%");
                });
            })
            ->when($role, function ($query) use ($role) {
                $query->whereHas('roles', function ($q) use ($role) {
                    $q->where('name', $role);
                });
            })
            ->when($status !== null && $status !== '', function ($query) use ($status) {
                $isActive = $status === 'active';
                $query->where('is_active', $isActive);
            });

        $users = $query
            ->orderByDesc('created_at')
            ->orderByDesc('id')
            ->paginate($perPage);

        return response()->json([
            'success' => true,
            'data' => UserResource::collection($users),
            'meta' => [
                'current_page' => $users->currentPage(),
                'per_page' => $users->perPage(),
                'total' => $users->total(),
                'last_page' => $users->lastPage(),
                'from' => $users->firstItem(),
                'to' => $users->lastItem(),
            ]
        ]);
    }

    /**
     * Store a newly created user.
     */
    public function store(Request $request)
    {
        $this->authorize('create', User::class);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'phone' => 'required|string|unique:users',
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
            'type' => 'required|in:admin,seller,buyer',
            'company_name' => 'nullable|string|max:255',
            'address' => 'nullable|string',
            'city' => 'nullable|string',
            'state' => 'nullable|string',
            'account_number' => 'nullable|string'
        ]);

        //user_id generation
        $validated['user_id'] = 'USER-' . strtoupper(Str::random(9));

        return DB::transaction(function () use ($validated) {
            $user = User::create([
                'name' => $validated['name'],
                'user_id' => $validated['user_id'],
                'email' => $validated['email'],
                'phone' => $validated['phone'],
                'password' => Hash::make($validated['password']),
                'type' => $validated['type'],
                'company_name' => $validated['company_name'] ?? null,
                'address' => $validated['address'] ?? null,
                'city' => $validated['city'] ?? null,
                'state' => $validated['state'] ?? null,
            ]);

            // Assign role based on type
            $user->assignRole($validated['type']);

            return response()->json([
                'success' => true,
                'data' => new UserResource($user),
                'message' => __('messages.users.created')
            ], 201);
        });
    }

    /**
     * Display the specified user.
     */
    public function show(User $user)
    {
        $this->authorize('view', $user);

        return response()->json([
            'success' => true,
            'data' => new UserResource($user->load('roles'))
        ]);
    }

    public function showProfile(Request $request)
    {
        $user = $request->user();

        return response()->json([
            'success' => true,
            'data' => new UserResource($user->load('roles'))
        ]);
    }


    /**
     * Update the specified user.
     */
    public function update(Request $request, User $user)
    {
        $this->authorize('update', $user);

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|string|email|max:255|unique:users,email,' . $user->id,
            'phone' => 'sometimes|string|unique:users,phone,' . $user->id,
            'password' => ['sometimes', 'confirmed', Rules\Password::defaults()],
            'type' => 'sometimes|in:admin,seller,buyer',
            'is_active' => 'sometimes|boolean',
            'status' => 'sometimes|in:active,inactive,suspended,disabled,restricted',
            'address' => 'nullable|string',
            'city' => 'nullable|string',
            'state' => 'nullable|string',
            'country' => 'nullable|string|max:100',
            'postal_code' => 'nullable|string|max:20',
            'date_of_birth' => 'nullable|date',
            'profile_photo' => 'nullable|string|max:500',
        ]);

        return DB::transaction(function () use ($validated, $user, $request) {
            $updateData = array_filter([
                'name' => $validated['name'] ?? null,
                'email' => $validated['email'] ?? null,
                'phone' => $validated['phone'] ?? null,
                'is_active' => $validated['is_active'] ?? null,
                'status' => $validated['status'] ?? null,
                'address' => $validated['address'] ?? null,
                'city' => $validated['city'] ?? null,
                'state' => $validated['state'] ?? null,
                'country' => $validated['country'] ?? null,
                'postal_code' => $validated['postal_code'] ?? null,
                'date_of_birth' => $validated['date_of_birth'] ?? null,
                'profile_photo' => $validated['profile_photo'] ?? null,
            ], fn($v) => $v !== null);

            if ($request->has('password')) {
                $updateData['password'] = Hash::make($validated['password']);
            }

            if ($request->has('is_active') && ! $request->has('status')) {
                $updateData['status'] = $request->boolean('is_active') ? 'active' : 'inactive';
            }

            if ($request->has('type') && $user->type !== $validated['type']) {
                $updateData['type'] = $validated['type'];
                $user->syncRoles($validated['type']);
            }

            $user->update($updateData);

            return response()->json([
                'success' => true,
                'data' => new UserResource($user->fresh()->load('roles')),
                'message' => __('messages.users.updated')
            ]);
        });
    }

    /**
     * Remove the specified user.
     *
     * Soft-deletes the user.  The User::booted() deleting listener
     * automatically cascades the soft-delete to the seller_profile and its
     * products, because the DB-level onDelete('cascade') only fires on hard
     * deletes — not on soft deletes — so we handle it at the application level.
     */
    public function destroy(User $user)
    {
        $this->authorize('delete', $user);

        // Prevent wiping out the very last admin account.
        if ($user->hasRole('admin')) {
            $adminCount = User::role('admin')->count();
            if ($adminCount <= 1) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot delete the last administrator account.',
                ], 422);
            }
        }

        DB::transaction(function () use ($user) {
            // Revoke all Sanctum tokens so the session is invalidated immediately.
            $user->tokens()->delete();

            // Detach Spatie roles (pivot table — no soft-delete on this table).
            $user->roles()->detach();

            // $user->delete() triggers the User::booted() deleting listener which
            // cascades the soft-delete to seller_profile → products.
            $user->delete();
        });

        return response()->json([
            'success' => true,
            'message' => __('messages.users.deleted'),
        ]);
    }

    /**
     * Assign roles to a user.
     */
    public function assignRoles(Request $request, User $user)
    {
        $this->authorize('assignRoles', $user);

        $validated = $request->validate([
            'roles' => 'required|array',
            'roles.*' => 'exists:roles,name'
        ]);

        $user->syncRoles($validated['roles']);

        return response()->json([
            'success' => true,
            'data' => new UserResource($user->load('roles')),
            'message' => __('messages.users.roles_assigned')
        ]);
    }

    /**
     * Get available roles.
     */
    public function getRoles()
    {
        $this->authorize('viewAny', Role::class);

        $roles = Role::all();

        return response()->json([
            'success' => true,
            'data' => $roles
        ]);
    }

    /**
     * Update user profile (for any authenticated user — all roles).
     */
    public function updateProfile(Request $request)
    {
        $user = $request->user();

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'email' => 'sometimes|string|email|max:255|unique:users,email,' . $user->id,
            'phone' => 'sometimes|string|unique:users,phone,' . $user->id,
            'address' => 'nullable|string',
            'city' => 'nullable|string',
            'township' => 'nullable|string|max:120',
            'state' => 'nullable|string',
            'country' => 'nullable|string|max:100',
            'postal_code' => 'nullable|string|max:20',
            'date_of_birth' => 'nullable|date|before:today',
            // Profile photo: accepts a relative storage path returned by the upload endpoint
            'profile_photo' => 'nullable|string|max:500',
        ]);

        return DB::transaction(function () use ($validated, $user) {
            $user->update($validated);

            return response()->json([
                'success' => true,
                'data' => new UserResource($user->fresh()->load('roles')),
                'message' => 'Profile updated successfully',
            ]);
        });
    }

    /**
     * Change user password.
     */
    public function changePassword(Request $request)
    {
        $user = $request->user();

        $validated = $request->validate([
            'current_password' => [
                'required',
                function ($attribute, $value, $fail) use ($user) {
                    if (!Hash::check($value, $user->password)) {
                        $fail('The current password is incorrect.');
                    }
                }
            ],
            'new_password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);

        $user->update([
            'password' => Hash::make($validated['new_password'])
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Password changed successfully'
        ]);
    }

    public function stats(Request $request)
    {
        $user = $request->user();

        $stats = [
            'total_orders' => $user->orders()->count(),
            'total_revenue' => (float) $user->orders()->sum('total_amount'),      // FIX: was 'total'
            'average_order_value' => (float) $user->orders()->avg('total_amount') ?? 0, // FIX: was 'total'
        ];

        return response()->json([
            'success' => true,
            'data' => $stats,
        ]);
    }

    public function updateNotificationPreferences(Request $request)
    {
        $user = $request->user();

        $validated = $request->validate([
            'order_updates' => 'sometimes|boolean',
            'promotional_emails' => 'sometimes|boolean',
            'newsletter' => 'sometimes|boolean',
            'security_alerts' => 'sometimes|boolean',
            'new_orders' => 'sometimes|boolean',
            'review_notifications' => 'sometimes|boolean',
            'seller_updates' => 'sometimes|boolean',
        ]);

        $existing = $user->notification_preferences ?? [];

        $user->update([
            'notification_preferences' => array_merge($existing, $validated)
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Notification preferences updated successfully',
            'data' => $user->notification_preferences
        ]);
    }

    /**
     * Schedule the authenticated user's account for deletion after the grace period.
     */
    public function destroyProfile(Request $request)
    {
        $user = $request->user();

        if ($user->hasRole('admin')) {
            return response()->json([
                'success' => false,
                'message' => __('messages.users.admin_cannot_self_delete'),
            ], 422);
        }

        if ($user->hasPendingDeletion()) {
            return response()->json([
                'success' => true,
                'message' => __('messages.users.deletion_already_scheduled'),
                'data' => [
                    'deletion_requested_at' => $user->deletion_requested_at,
                    'deletion_scheduled_at' => $user->deletionScheduledAt(),
                ],
            ]);
        }

        if ($this->accountDeletion->hasBlockingActiveOrders($user)) {
            return response()->json([
                'success' => false,
                'message' => __('messages.users.pending_orders_block_delete'),
            ], 422);
        }

        if ($this->accountDeletion->hasBlockingOpenReports($user)) {
            return response()->json([
                'success' => false,
                'message' => __('messages.users.active_disputes_block_delete'),
            ], 422);
        }

        $user = $this->accountDeletion->scheduleDeletion($user);

        return response()->json([
            'success' => true,
            'message' => __('messages.users.deletion_scheduled', [
                'days' => $this->accountDeletion->graceDays(),
            ]),
            'data' => [
                'deletion_requested_at' => $user->deletion_requested_at,
                'deletion_scheduled_at' => $user->deletionScheduledAt(),
            ],
        ]);
    }

    /**
     * Cancel a pending account deletion and restore access.
     */
    public function cancelAccountDeletion(Request $request)
    {
        $user = $request->user();

        if (!$user->canRecoverFromPendingDeletion()) {
            return response()->json([
                'success' => false,
                'message' => __('messages.users.deletion_cannot_be_cancelled'),
            ], 422);
        }

        $user = $this->accountDeletion->cancelDeletion($user);

        return response()->json([
            'success' => true,
            'message' => __('messages.users.deletion_cancelled'),
            'data' => new UserResource($user->load('roles')),
        ]);
    }
}
